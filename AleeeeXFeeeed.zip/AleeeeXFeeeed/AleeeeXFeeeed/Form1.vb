﻿Imports System.Net
Imports System.Net.Sockets
Imports System.Text

Public Class Form1

    Dim tcpClient As New System.Net.Sockets.TcpClient()



    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load


        tcpClient.Connect("192.168.0.1", 8000)

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            If tcpClient.Connected = True Then
            Else
                tcpClient.Connect("192.168.0.1", 8000)
            End If

            Dim networkStream As NetworkStream = tcpClient.GetStream()
            If networkStream.CanWrite And networkStream.CanRead Then
                Dim bytes(tcpClient.ReceiveBufferSize) As Byte
                networkStream.Read(bytes, 0, CInt(tcpClient.ReceiveBufferSize))
                ' Output the data received from the host to the console.
                Dim returndata As String = Encoding.ASCII.GetString(bytes)
                returndata = returndata.Substring(returndata.LastIndexOf(")") + 2)
                returndata = returndata.Substring(0, returndata.LastIndexOf("00"))
                TextBox1.Text = returndata.Trim
            End If
        Catch ex As Exception
        End Try
    End Sub



    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Try
            If tcpClient.Connected = True Then
            Else
                tcpClient.Connect("192.168.0.1", 8000)
            End If

            Dim networkStream As NetworkStream = tcpClient.GetStream()
            If networkStream.CanWrite And networkStream.CanRead Then
                Dim bytes(tcpClient.ReceiveBufferSize) As Byte
                networkStream.Read(bytes, 0, CInt(tcpClient.ReceiveBufferSize))
                ' Output the data received from the host to the console.
                Dim returndata As String = Encoding.ASCII.GetString(bytes)
                returndata = returndata.Substring(returndata.LastIndexOf(")") + 2)
                returndata = returndata.Substring(0, returndata.LastIndexOf("00"))
                TextBox1.Text = returndata.Trim
            End If
        Catch ex As Exception
        End Try
    End Sub
End Class
